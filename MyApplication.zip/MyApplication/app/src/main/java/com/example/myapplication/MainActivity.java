package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView outp;
    String currentInput = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outp = findViewById(R.id.ov);

        Button B1 = findViewById(R.id.b1);
        Button B2 = findViewById(R.id.b2);
        Button B3 = findViewById(R.id.b3);
        Button B4 = findViewById(R.id.b4);
        Button B5 = findViewById(R.id.b5);
        Button B6 = findViewById(R.id.b6);
        Button B7 = findViewById(R.id.b7);
        Button B8 = findViewById(R.id.b8);
        Button B9 = findViewById(R.id.b9);
        Button B10 = findViewById(R.id.b10);
        Button B11 = findViewById(R.id.b11);
        Button B12 = findViewById(R.id.b12);
        Button B13 = findViewById(R.id.b13);
        Button B14 = findViewById(R.id.b14);
        Button B15 = findViewById(R.id.b15);
        Button B16 = findViewById(R.id.b16);
        Button B17 = findViewById(R.id.b17);
        Button B18 = findViewById(R.id.b18);
        Button B19 = findViewById(R.id.b19);

        B1.setText("C");
        B2.setText("%");
        B3.setText("<-");
        B4.setText("/");
        B5.setText("*");
        B6.setText("-");
        B7.setText("+");
        B8.setText("=");
        B9.setText("7");
        B10.setText("8");
        B11.setText("9");
        B12.setText("6");
        B13.setText("4");
        B14.setText("5");
        B15.setText("3");
        B16.setText("2");
        B17.setText("1");
        B18.setText("0");
        B19.setText(".");

        // Set onClickListener for all buttons
        B1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

        B19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });
    }

    public void onButtonClick(View view) {
        if (view instanceof Button) {
            Button clickedButton = (Button) view;
            String buttonText = clickedButton.getText().toString();

            switch (buttonText) {
                case "C":
                    currentInput = "";
                    break;
                case "<-":
                    if (!currentInput.isEmpty()) {
                        currentInput = currentInput.substring(0, currentInput.length() - 1);
                    }
                    break;
                case "=":
                    try {
                        double result = evaluateExpression(currentInput);
                        currentInput = Double.toString(result);
                    } catch (Exception e) {
                        currentInput = "Error";
                    }
                    break;
                default:
                    currentInput += buttonText;
                    break;
            }

            outp.setText(currentInput);
        }
    }

    private double evaluateExpression(String expression) {
        String[] parts;

        if (expression.contains("+")) {
            parts = expression.split("\\+");
        }
        else if (expression.contains("-")) {
            parts = expression.split("-");
        }
        else if (expression.contains("*")) {
            parts = expression.split("\\*");
        }
        else if (expression.contains("/")) {
            parts = expression.split("/");
        }
        else if (expression.contains("%")) {
            parts = expression.split("%");
        }
        else {
            return 0.0;
        }

        if (parts.length != 2) {
            return 0.0;
        }

        double operand1 = Double.parseDouble(parts[0]);
        double operand2 = Double.parseDouble(parts[1]);

        char operator = expression.charAt(parts[0].length());

        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                if (operand2 != 0) {
                    return operand1 / operand2;
                } else {

                    return Double.POSITIVE_INFINITY;
                }
            case '%':
                return operand1 % operand2;
            default:
                return 0.0;
        }
    }
}
